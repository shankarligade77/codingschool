import { useNavigate } from "react-router-dom";

function Register(){
    const navigate=useNavigate()
const onRegister=()=>{
    alert("Registration Successfull")
    navigate('/')
}
    return <div className="container-md">
      <fieldset >
        
        <div class="form-group col-6">
          <label>FirstName</label>
          <input type="text" class="form-control"/>
        </div>

        <div class="form-group col-6">
          <label>LastName</label>
          <input type="text" class="form-control"/>
        </div>
        <div class="form-group col-6">
          <label>Email</label>
          <input type="email" class="form-control"/>
        </div>
        <div class="form-group col-6">
          <label>Password</label>
          <input  type="password" class="form-control"/>
        </div>
        <div class="form-group col-6">
          <label>Confirm Password</label>
          <input  type="password" class="form-control"/>
        </div>
    <div class="form-group col-6">
   
    <button type="submit" class="btn btn-primary col-2 m-2" onClick={onRegister}>Register</button>
    </div>




      </fieldset>
    </div>
}
export default Register;