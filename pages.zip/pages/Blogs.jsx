import { useNavigate } from "react-router-dom";

function Blogs(){
const navigate=useNavigate();


const blogsInfo=[
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    },
    {
        id:1,
        title:"food Technology",
        content:"This Blog is all about Information................................................",
    
    }
]






return <div className="container">

   {blogsInfo.map(info=>{
    return(
        <div className="container-blog">
            <h1>{info.id}</h1><span>{info.title}</span>
            <div>
                {info.content}
            </div>
        </div>
    )
   })}
</div>




}
export default Blogs;