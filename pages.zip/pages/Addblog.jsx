function Addblog(){

return <div>

<div className="container">

<label>Title</label><br />
<input type="text" name="" id="" /><br />
<label>Content</label><br />
<textarea name="" id="" cols="30" rows="10"></textarea><br />

<button>Cancel</button>&nbsp;&nbsp;&nbsp;
<button>Save</button>


</div>


    </div>





}
export default Addblog;