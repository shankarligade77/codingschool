import { useNavigate } from "react-router-dom";




function Login() {
    const navigate=useNavigate();



    const onLogin=()=>{
        alert('Login Successful')
        navigate('/blog')
    }

    const onRegister=()=>{
        navigate('/register')
    }
  return (
    <div className="container-md box">
      <fieldset >
        
        <div class="form-group col-6">
          <label><b>UserName or Email</b></label>
          <input type="text" class="form-control"/>
        </div>
        <div class="form-group col-6">
          <label><b>Password</b></label>
          <input  type="password" class="form-control"/>
        </div>
    <div class="form-group col-10 btn1">
    <button type="submit" class="btn btn-success col-2 m-2" onClick={onLogin}>Login</button>
    <button type="submit" class="btn btn-primary col-2 m-2" onClick={onRegister}>Register</button>
    </div>




      </fieldset>
    </div>
  );
}
export default Login;
